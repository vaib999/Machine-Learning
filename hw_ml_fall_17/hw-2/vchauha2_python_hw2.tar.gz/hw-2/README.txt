I have used python 3 for this project.
I have made separate files for stemmed document(stemmed folder) and for 
removing stopwords and then stemming it(stop_stem folder).

I have done this because by removing stop words and then stemming it is 
giving more accuracy.

After removing stop words I am getting better accuracy because by including
stopwords the conditional probability of words that contribute higher
to classifiying ham or spam were reduced. So by removing them those words
had more conditional probability and thus helped in correct classification.